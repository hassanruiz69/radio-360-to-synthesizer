#!/usr/bin/env python3
"""Ejecuta la simulacion completa: senal de radio simulada -> imagen 360 equirectangular.

Uso:
    python scripts/run_simulation.py [--width 2048] [--seed 42] [--out outputs/]

Tambien puede cargar un WAV real:
    python scripts/run_simulation.py --wav mi_senal.wav
"""

from __future__ import annotations

import argparse
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from r360.input import simulate_radio_signal, load_wav
from r360.processing import compute_spectrogram, extract_features
from r360.mapping import features_to_heightmap
from r360.render import render_equirectangular, render_diagnostic


def main():
    ap = argparse.ArgumentParser(description="Radio-to-360 Spatial Synthesizer (simulacion)")
    ap.add_argument("--wav", type=str, default=None, help="WAV real en lugar de senal simulada")
    ap.add_argument("--width", type=int, default=2048, help="Ancho de la imagen equirectangular (alto=ancho/2)")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--duration", type=float, default=8.0)
    ap.add_argument("--out", type=str, default=os.path.join(os.path.dirname(__file__), "..", "outputs"))
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    tag = time.strftime("%Y%m%d_%H%M%S")

    # --- Capa 1: Input ---
    if args.wav:
        signal, fs, meta = load_wav(args.wav)
        source_name = os.path.basename(args.wav)
    else:
        signal, fs, meta = simulate_radio_signal(duration=args.duration, seed=args.seed)
        source_name = f"sim_seed{args.seed}"

    print(f"[1/4] Input: {meta['source']} | {len(signal)} muestras @ {fs:.0f} Hz | {len(signal)/fs:.1f}s")

    # --- Capa 2: Procesamiento ---
    f, t, mag_db, phase = compute_spectrogram(signal, fs, nperseg=1024)
    features = extract_features(f, t, mag_db, phase, n_peaks=6)
    print(f"[2/4] STFT: {len(f)} freqs x {len(t)} ventanas | "
          f"coherencia de fase = {features['phase_coherence']:.3f} | "
          f"{len(features['anchors'])} picos anclaje")
    for a in features["anchors"]:
        print(f"       ancla @ {a['freq_hz']:.0f} Hz (altura {a['height']:.2f})")

    # --- Capa 3: Mapeo a lienzo equirectangular ---
    H, anchors_px, aux = features_to_heightmap(features, width=args.width, seed=args.seed)
    print(f"[3/4] Heightmap: {H.shape[1]}x{H.shape[0]} (2:1) | {len(anchors_px)} monolitos")

    # --- Capa 4: Render ---
    final_path = os.path.join(args.out, f"r360_{source_name}_{tag}.png")
    render_equirectangular(H, anchors_px, aux, final_path, seed=args.seed)
    diag_path = os.path.join(args.out, f"r360_{source_name}_{tag}_diagnostic.png")
    render_diagnostic(signal, fs, features, H, final_path, diag_path)

    print(f"[4/4] Listo.")
    print(f"       Imagen 360: {final_path}")
    print(f"       Diagnostico: {diag_path}")
    print(f"       Visor: abre viewer/index.html y arrastra la PNG, o sirve la carpeta outputs/")


if __name__ == "__main__":
    main()
