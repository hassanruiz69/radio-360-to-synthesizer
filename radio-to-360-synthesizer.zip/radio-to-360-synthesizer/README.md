# Radio-to-360 Spatial Synthesizer

> Materializa mundos hipotéticos en 360° a partir de ondas de radio.
> Data Art × Computación Espacial × Creative Coding.

Este proyecto traduce señales del espectro electromagnético (audio, SDR,
telemetría o espectros simulados de radioastronomía) en **imágenes
equirectangulares 2:1** que pueden visualizarse como entornos inmersivos
de 360° (WebXR, planetarios, visores VR). La señal original dicta,
matemáticamente, la geometría, el color y los "monolitos de anclaje" del
mundo generado.

---

## ⚠️ Viabilidad real en astronomía (léelo antes de usarlo como ciencia)

Este repositorio es, ante todo, **arte de datos y divulgación**. No es un
instrumento de medición. La evaluación honesta:

### Lo que SÍ es práctico y real
- **Sonificación / visualización inmersiva de datos astronómicos es un campo
  establecido.** NASA (Chandra, Webb), Rubin Observatory (Skysynth), ESO
  (Audio Universe) y MIT convierten rutinariamente señales invisibles en
  experiencia sensorial. Un sinte 360° a partir de mapos de radio encaja en
  esa línea y es útil para *outreach*, accesibilidad y narrativa científica.
- **Existen datos de radioastronomía públicos reales** (encuestas HI 21cm,
  VLA, ALMA, MeerKAT) que pueden alimentar el pipeline como entrada legítima.
- Como **herramienta de worldbuilding inmersivo** y **demo técnica** (SDR +
  DSP + WebXR) es completamente válido y atractivo.

### Lo que NO es práctico (ni científico)
- **El mapeo señal→geometría es arbitrario y expresivo.** No hay una
  correspondencia física única entre una frecuencia de radio y una
  coordenada esférica; el mundo generado no es invertible ni medible.
  Cualquier conclusión "astronómica" sacada de la imagen sería pseudociencia.
- **Capturar "señales de radio reales del entorno" con un SDR de consumo en
  ciudad no capta el cosmos:** el 40–70% del espectro urbano es interferencia
  humana (RFI: WiFi, móvil, FM, fuentes conmutadas). Un RTL-SDR tiene ADC de
  8 bits (~48 dB de rango dinámico), deriva de 50–100 ppm, y no detecta
  fuentes más débiles que ~100 Jy. Verás ruido y RFI, no hidrógeno neutro.
- Si quieres entrada *realmente astronómica*, usa archivos de encuestas
  públicas o un radiotelescopio amateur calibrado (Radio JOVE, Itty Bitty
  Telescope) en zona libre de RFI — no un dongle en un departamento.

**Conclusión:** práctico como arte/divulgación/visión inmersiva de datos
reales; impráctico y engañoso como instrumento científico si se presenta
como tal. El repositorio está etiquetado como Data Art en consonancia.

---

## Arquitectura (3 capas)

```
┌─────────────────────────────┐
│ 1. INPUT                     │  WAV / SDR-IQ / simulación (HI+Pulsar+RFI)
├─────────────────────────────┤
│ 2. PROCESSING (NumPy/SciPy)  │  STFT, espectrograma, centroid, RMS, picos, fase
├─────────────────────────────┤
│ 3. MAPPING + RENDER          │  rasgos → heightmap equirectangular (2:1) → PNG
└─────────────────────────────┘
```

- `src/r360/input.py` — simulación realista (ruido cósmico + línea HI 21cm +
  pulsar con dispersión + RFI urbano), carga de WAV, stub para IQ de SDR.
- `src/r360/processing.py` — STFT, extracción de rasgos espectrales y picos
  anclaje.
- `src/r360/mapping.py` — rasgos → campo de altura en lienzo 2:1 (deformación
  atenuada por cos(latitud) para que se vea bien en una esfera).
- `src/r360/render.py` — heightmap + anclas → PNG equirectangular + figura de
  diagnóstico (waveform / espectrograma / heightmap / resultado).
- `viewer/index.html` — visor WebXR (A-Frame): arrastra la PNG y mira el
  mundo en 360°, con botón ENTER VR si hay headset.

## Uso rápido

```bash
pip install -r requirements.txt
python scripts/run_simulation.py --width 2048 --seed 42
# genera outputs/r360_*.png  (2:1 equirectangular) y su diagnóstico
# abre viewer/index.html en el navegador y arrastra la PNG
```

Con un audio real:
```bash
python scripts/run_simulation.py --wav mi_senal.wav
```

## Resultado de la simulación incluida

Señal simulada de 8 s (ruido cósmico + línea HI ~1720 Hz + pulsar 0.71 s +
4 portadoras RFI). El pipeline detecta automáticamente los picos
espectrales y los convierte en monolitos anclaje. La línea HI (el pico más
fuerte) se materializa como la estructura dominante. Ejemplo de salida en
`outputs/`.

## Roadmap (PR bienvenidos)

- [ ] Integración con pipelines de difusión locales (Stable Diffusion XL) /
  Amazon Bedrock para texturizar el heightmap con prompts estructurados.
- [ ] Captura SDR en vivo con `pyrtlsdr` + flaggeo de RFI.
- [ ] Carga de espectros HI 21cm reales desde surveys públicos.
- [ ] Proyección estereoscópica y exportación a glTF para mundos VR.

## Licencia

MIT — úsalo, modifícalo, y si expones el resultado como ciencia, cita que es
Data Art.
