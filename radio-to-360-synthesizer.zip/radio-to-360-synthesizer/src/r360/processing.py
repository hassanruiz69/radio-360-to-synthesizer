"""Motor de procesamiento: STFT, extraccion de rasgos espectrales.

De la senal 1D extrae:
  - Espectrograma (magnitud en dB + fase).
  - Por ventana temporal: centroid espectral, ancho de banda, RMS, frecuencia dominante.
  - Global: picos espectrales (candidatos a "puntos de anclaje"), coherencia de fase.
"""

from __future__ import annotations

import numpy as np
from scipy import signal as sig


def compute_spectrogram(
    x: np.ndarray, fs: float, nperseg: int = 1024, noverlap: int | None = None
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Retorna (f, t, mag_db, phase)."""
    if noverlap is None:
        noverlap = nperseg // 2
    f, t, Zxx = sig.stft(x, fs=fs, nperseg=nperseg, noverlap=noverlap, boundary="zeros")
    mag = np.abs(Zxx) + 1e-12
    mag_db = 20.0 * np.log10(mag)
    phase = np.angle(Zxx)
    return f, t, mag_db, phase


def extract_features(
    f: np.ndarray, t: np.ndarray, mag_db: np.ndarray, phase: np.ndarray, n_peaks: int = 6
) -> dict:
    """Extrae rasgos de control para el mapeo generativo."""
    mag = 10 ** (mag_db / 20.0)  # magnitud lineal
    mag_norm = (mag - mag.min()) / (mag.ptp() + 1e-12)

    # Por ventana (a lo largo del tiempo, axis=1)
    sum_mag = mag.sum(axis=0) + 1e-12
    spectral_centroid = (f[:, None] * mag).sum(axis=0) / sum_mag
    spectral_bandwidth = np.sqrt(((f[:, None] - spectral_centroid[None, :]) ** 2 * mag).sum(axis=0) / sum_mag)
    rms_envelope = np.sqrt((mag**2).mean(axis=0))

    # Frecuencia dominante por ventana
    dominant_idx = mag.argmax(axis=0)
    dominant_freq = f[dominant_idx]

    # Picos espectrales globales (promedio temporal) -> puntos de anclaje
    avg_spectrum = mag.mean(axis=1)
    peak_idx, props = sig.find_peaks(avg_spectrum, height=avg_spectrum.mean() * 1.2, distance=len(f) // 20)
    if len(peak_idx) > n_peaks:
        order = np.argsort(props["peak_heights"])[::-1][:n_peaks]
        peak_idx = peak_idx[order]
    anchors = [
        {
            "freq_hz": float(f[p]),
            "height": float(avg_spectrum[p] / (avg_spectrum.max() + 1e-12)),
            "phase": float(phase[p, :].mean()),
        }
        for p in peak_idx
    ]

    # Coherencia de fase media (que tan "estructurada" es la senal)
    phase_coherence = float(np.abs(np.mean(np.exp(1j * phase))))

    return {
        "f": f,
        "t": t,
        "mag_db": mag_db,
        "mag_norm": mag_norm,
        "phase": phase,
        "spectral_centroid": spectral_centroid,
        "spectral_bandwidth": spectral_bandwidth,
        "rms_envelope": rms_envelope,
        "dominant_freq": dominant_freq,
        "anchors": anchors,
        "phase_coherence": phase_coherence,
    }
