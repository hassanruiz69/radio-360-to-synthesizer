"""Render: heightmap + anclas -> imagen equirectangular RGB (2:1).

Paleta intencionalmente ciberpunk-espacial pero sin abuso de purpuro/indigo:
negro profundo, cian/teal, ambar, acentos magenta.
"""

from __future__ import annotations

import numpy as np
from PIL import Image


# Paleta base (RGB 0-1)
C_DEEP = np.array([0.02, 0.03, 0.06])
C_TEAL = np.array([0.0, 0.85, 0.95])
C_AMBER = np.array([1.0, 0.55, 0.12])
C_MAGENTA = np.array([1.0, 0.15, 0.45])
C_CYAN_HOT = np.array([0.6, 1.0, 1.0])


def _lerp(a, b, t):
    return a + (b - a) * t[..., None]


def render_equirectangular(
    H: np.ndarray,
    anchors_px: list,
    aux: dict,
    out_path: str,
    star_density: float = 0.0006,
    seed: int = 11,
) -> str:
    """Renderiza el heightmap a PNG equirectangular. Retorna ruta."""
    rows, width = H.shape
    rng = np.random.default_rng(seed)

    centroid_w = aux["centroid_w"]  # (W,)
    c_norm = (centroid_w - centroid_w.min()) / (centroid_w.ptp() + 1e-12)

    # 0) Estiramiento de contraste del heightmap (gamma + recorte)
    Hc = np.clip((H - 0.25) / 0.6, 0, 1)
    Hc = Hc ** 0.75

    # Gradiente latitudinal: polo norte (arriba) mas frio/oscuro, ecuador mas calido
    lat_grad = np.linspace(0.0, 1.0, rows)[:, None]  # 0 arriba, 1 abajo

    # 1) Color base por elevacion: deep -> teal -> amber en picos
    img = _lerp(C_DEEP, C_TEAL, np.clip(Hc * 1.3, 0, 1))
    high = np.clip((Hc - 0.6) / 0.4, 0, 1)
    img = _lerp(img, C_AMBER, high * 0.9)
    # Tinte segun latitud (mitad inferior mas verdoso/terreno, mitad superior mas azulado/cielo)
    img = _lerp(img, img * np.array([0.7, 1.1, 1.2]), (1 - lat_grad) * 0.4)
    img = _lerp(img, img * np.array([1.15, 1.0, 0.7]), lat_grad * 0.4)

    # 2) Shift de tono por columna segun centroid espectral
    hue_shift = (c_norm[None, :] - 0.5) * 0.45
    img[..., 0] = np.clip(img[..., 0] + hue_shift * 0.8, 0, 1)
    img[..., 2] = np.clip(img[..., 2] - hue_shift, 0, 1)
    img[..., 1] = np.clip(img[..., 1] + hue_shift * 0.3, 0, 1)

    # 3) Brillo ecuatorial (fase coherente -> banda de energia)
    equator = np.exp(-((np.arange(rows) - rows / 2) ** 2) / (2 * (rows / 10) ** 2))[:, None]
    glow = aux["rms_w"][None, :] / (aux["rms_w"].max() + 1e-9)
    band = equator * glow * 0.35
    img = np.clip(img + band[..., None] * C_CYAN_HOT[None, None, :], 0, 1)

    # 4) Resplandor radial en cada punto de anclaje (monolitos)
    yy, xx = np.mgrid[0:rows, 0:width]
    for (x, y, intensity) in anchors_px:
        d2 = (xx - x) ** 2 + ((yy - y) * 1.8) ** 2  # alargado verticalmente
        halo = intensity * np.exp(-d2 / (2 * (width / 22) ** 2))
        color = C_MAGENTA if (x // (width // max(1, len(anchors_px)))) % 2 == 0 else C_CYAN_HOT
        img = np.clip(img + halo[..., None] * color[None, None, :], 0, 1)
        # nucleo del monolito: linea vertical brillante
        core = intensity * np.exp(-((xx - x) ** 2) / (2 * (width / 400) ** 2))
        core *= np.exp(-((yy - y) ** 2) / (2 * (rows / 6) ** 2))
        img = np.clip(img + core[..., None] * 1.2, 0, 1)

    # 5) Estrellas/fantasmas: puntos brillantes en zonas bajas (valles = "cielo de datos")
    n_stars = int(star_density * rows * width)
    if n_stars > 0:
        sy = rng.integers(0, rows, n_stars)
        sx = rng.integers(0, width, n_stars)
        mask = H[sy, sx] < 0.35
        sy, sx = sy[mask], sx[mask]
        brightness = rng.uniform(0.3, 1.0, len(sy))
        img[sy, sx] = np.clip(img[sy, sx] + brightness[:, None] * 0.8, 0, 1)

    # 6) Viietado suave en polos para ocultar distorsion equirectangular
    pole_vignette = 0.6 + 0.4 * np.cos(np.linspace(-np.pi / 2, np.pi / 2, rows))[:, None]
    img *= pole_vignette[..., None]

    img_u8 = (np.clip(img, 0, 1) * 255).astype(np.uint8)
    Image.fromarray(img_u8, mode="RGB").save(out_path)
    return out_path


def render_diagnostic(
    signal: np.ndarray,
    fs: float,
    features: dict,
    H: np.ndarray,
    final_img_path: str,
    out_path: str,
) -> str:
    """Figura de diagnostico: waveform + espectrograma + heightmap + resultado final."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from PIL import Image

    fig, axes = plt.subplots(2, 2, figsize=(16, 9))
    t = np.arange(len(signal)) / fs
    axes[0, 0].plot(t[::10], signal[::10], lw=0.4, color="#00d4ff")
    axes[0, 0].set_title("Waveform (audio-rate downsampled)")
    axes[0, 0].set_xlabel("time [s]")

    f = features["f"]
    tt = features["t"]
    axes[0, 1].pcolormesh(tt, f, features["mag_db"], shading="auto", cmap="inferno", vmin=-60)
    axes[0, 1].set_title("Spectrogram (STFT)")
    axes[0, 1].set_ylabel("freq [Hz]")
    axes[0, 1].set_xlabel("time [s]")

    axes[1, 0].imshow(H, aspect="auto", cmap="viridis")
    axes[1, 0].set_title("Derived heightmap (equirectangular 2:1)")
    axes[1, 0].axis("off")

    axes[1, 1].imshow(np.asarray(Image.open(final_img_path)))
    axes[1, 1].set_title("Final 360 equirectangular (view in viewer/index.html)")
    axes[1, 1].axis("off")

    plt.tight_layout()
    diag_path = out_path
    fig.savefig(diag_path, dpi=110)
    plt.close(fig)
    return diag_path
