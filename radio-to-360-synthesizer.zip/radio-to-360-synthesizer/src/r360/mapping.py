"""Mapeo: rasgos espectrales -> campo geometrico en lienzo equirectangular (2:1).

El lienzo equirectangular tiene W x H = W x (W/2). El eje X es longitud
(0..2pi, se envuelve), el eje Y es latitud (-pi/2 polo sur .. +pi/2 polo norte).
Para que la textura se vea bien en una esfera, la deformacion se atenua por
cos(latitud) cerca de los polos.

Convencion: el mapeo es EXPRESIVO (data art). No hay correspondencia fisica
unica entre frecuencia y geometria; se elige una que maximice contraste
visual y legibilidad de la estructura de la senal.
"""

from __future__ import annotations

import numpy as np


def _resample_to_width(arr: np.ndarray, width: int) -> np.ndarray:
    """Remuestrea un array 1D o 2D (ultimo eje = tiempo) a `width` columnas."""
    x_old = np.linspace(0, 1, arr.shape[-1])
    x_new = np.linspace(0, 1, width)
    return np.interp(x_new, x_old, arr)


def _value_noise(rows: int, cols: int, scale: float, seed: int) -> np.ndarray:
    """Ruido de valor simple (suave) para terreno base."""
    rng = np.random.default_rng(seed)
    small_w = max(2, int(cols / scale))
    small_h = max(2, int(rows / scale))
    low = rng.random((small_h, small_w))
    # upsample bilinear
    yy = np.linspace(0, small_h - 1, rows)
    xx = np.linspace(0, small_w - 1, cols)
    x0 = np.floor(xx).astype(int); x1 = np.minimum(x0 + 1, small_w - 1)
    y0 = np.floor(yy).astype(int); y1 = np.minimum(y0 + 1, small_h - 1)
    fx = (xx - x0)[None, :]; fy = (yy - y0)[:, None]
    a = low[y0][:, x0]; b = low[y0][:, x1]; c = low[y1][:, x0]; d = low[y1][:, x1]
    return a * (1 - fx) * (1 - fy) + b * fx * (1 - fy) + c * (1 - fx) * fy + d * fx * fy


def features_to_heightmap(features: dict, width: int = 2048, seed: int = 7) -> tuple[np.ndarray, list]:
    """Convierte rasgos espectrales en un heightmap H (rows=width//2, cols=width).

    Retorna (H_normalizado_0_1, anchors_px) donde anchors_px son
    [(x_pixel, y_pixel, intensity), ...] para los "monolitos" anclaje.
    """
    rows = width // 2
    f = features["f"]
    mag_norm = features["mag_norm"]  # (F, T)
    phase = features["phase"]
    rms = features["rms_envelope"]
    centroid = features["spectral_centroid"]

    # 1) Agrupar frecuencias en N bandas logespaciadas -> amplitudes por banda a lo largo del tiempo
    n_bands = 6
    band_edges = np.logspace(np.log10(max(f[1], 1)), np.log10(f[-1]), n_bands + 1)
    band_amp = np.zeros((n_bands, mag_norm.shape[1]))
    band_phase = np.zeros((n_bands, mag_norm.shape[1]))
    for b in range(n_bands):
        mask = (f >= band_edges[b]) & (f < band_edges[b + 1])
        if mask.sum() == 0:
            continue
        band_amp[b] = mag_norm[mask].mean(axis=0)
        band_phase[b] = phase[mask].mean(axis=0)

    # 2) Remuestrear a `width` columnas (longitud)
    band_amp_w = np.stack([_resample_to_width(band_amp[b], width) for b in range(n_bands)])  # (B, W)
    band_phase_w = np.stack([_resample_to_width(band_phase[b], width) for b in range(n_bands)])
    rms_w = _resample_to_width(rms, width)
    centroid_w = _resample_to_width(centroid, width)

    # 3) Construir campo: y = latitud normalizada [-1, 1] (fila 0 = +1 polo norte)
    y_norm = np.linspace(1.0, -1.0, rows)[:, None]  # (rows, 1)
    lat = y_norm * np.pi / 2.0
    cos_lat = np.cos(lat)  # (rows,1) -> atenua deformacion cerca de polos

    H = np.zeros((rows, width), dtype=np.float64)
    # Cada banda impulsa una armonica espacial de frecuencia creciente a traves de la latitud.
    # Peso reducido para no dominar con franjas verticales.
    for b in range(n_bands):
        amp = band_amp_w[b][None, :]  # (1, W)
        ph = band_phase_w[b][None, :]
        spatial_freq = (b + 1) * 1.2
        contribution = amp * np.sin(spatial_freq * np.pi * y_norm + ph * 3.0)
        H += 0.35 * contribution * (0.5 + 0.5 * cos_lat)

    # 4) Terreno base (ruido de valor) modulado por envolvente RMS -> peso dominante
    noise = _value_noise(rows, width, scale=width / 12, seed=seed)
    noise += 0.6 * _value_noise(rows, width, scale=width / 5, seed=seed + 1)
    noise += 0.3 * _value_noise(rows, width, scale=width / 2.5, seed=seed + 2)
    noise = (noise - noise.mean()) / (noise.std() + 1e-9)
    H += 1.1 * noise * (0.35 + 0.65 * rms_w[None, :])

    # 5) Normalizar
    H = (H - H.min()) / (H.ptp() + 1e-12)

    # 6) Puntos de anclaje: picos espectrales -> monolitos verticales
    anchors = features["anchors"]
    anchors_px = []
    for i, a in enumerate(anchors):
        x = int(((i + 0.5) / max(1, len(anchors))) * width)
        # altura del ancla en latitud segun frecuencia normalizada
        freq_norm = (a["freq_hz"] - f.min()) / (f.ptp() + 1e-9)
        y = int((1.0 - freq_norm) * (rows - 1))  # frec alta -> cerca de polo norte
        anchors_px.append((x, y, float(a["height"])))
        # Grabar una "cicatriz" vertical en el heightmap en esa longitud
        col = H[:, x]
        col += 0.5 * a["height"] * np.exp(-((np.arange(rows) - y) ** 2) / (2 * (rows / 18) ** 2))
        H[:, x] = np.clip(col, 0, 1)

    return H.astype(np.float32), anchors_px, {"centroid_w": centroid_w, "rms_w": rms_w}
