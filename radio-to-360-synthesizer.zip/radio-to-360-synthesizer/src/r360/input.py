"""Capa de entrada: captura / simulacion de frecuencias.

Soporta tres modos:
  1. simulate_radio_signal()  -> senal realista sintetica (HI 21cm + pulsar + RFI + ruido cosmico)
  2. load_wav()               -> cualquier archivo de audio (necesita soundfile/scipy.io.wavfile)
  3. load_sdr_iq()            -> stub para IQ de SDR (RTL-SDR .raw / .cs16)

Nota sobre captura SDR real en entorno urbano: el 40-70% del espectro es
interferencia humana (RFI): WiFi, movil, radio FM, fuentes conmutadas.
Ver seccion "Viabilidad real" en el README.
"""

from __future__ import annotations

import numpy as np


def simulate_radio_signal(
    duration: float = 8.0,
    fs: float = 22050.0,
    seed: int = 42,
    include_rfi: bool = True,
) -> tuple[np.ndarray, float, dict]:
    """Genera una senal compuesta que imita una observacion de radioastronomia.

    Componentes (en banda base, trasladados a audio para poder procesarla con
    el mismo pipeline que un WAV):
      - Fondo cosmico: ruido gaussiano (CMB + fondo de galaxias).
      - Linea HI 21cm: una "linea espectral" modelada como ruido filtrado con
        perfil gaussiano en frecuencia (equivalente a emision/absorcion).
      - Pulsar: tren de pulsos periodicos con barrido de dispersion (chirp).
      - RFI (opcional): portadoras estrechas con encendido/apagado aleatorio.

    Retorna (signal_mono_float, fs, metadata).
    """
    rng = np.random.default_rng(seed)
    n = int(duration * fs)
    t = np.arange(n) / fs

    # 1) Fondo cosmico (ruido termico)
    signal = rng.normal(0.0, 0.35, n)

    # 2) Linea HI 21cm: portadora en f_hi con amplitud modulada por perfil gaussiano lento
    f_hi = 1420.0 % 4000 + 300  # frecuencia "audio" equivalente arbitraria
    hi_profile = 0.5 + 0.5 * np.exp(-((t - duration * 0.55) ** 2) / (2 * (duration * 0.18) ** 2))
    signal += 0.45 * hi_profile * np.sin(2 * np.pi * f_hi * t + rng.normal(0, 0.2, n))

    # 3) Pulsar: periodo ~0.71 s, pulso corto con chirp de dispersion
    period = 0.71
    pulse_width = 0.012
    n_pulses = int(duration / period)
    for k in range(n_pulses):
        t0 = k * period + 0.05
        idx = np.searchsorted(t, t0)
        w = int(pulse_width * fs)
        if idx + w < n:
            tt = np.arange(w) / fs
            # chirp descendente (dispersion)
            f0, f1 = 1800.0, 600.0
            chirp_phase = 2 * np.pi * (f0 * tt + 0.5 * (f1 - f0) / (w / fs) * tt**2)
            env = np.exp(-((tt - pulse_width / 2) ** 2) / (2 * (pulse_width / 4) ** 2))
            signal[idx : idx + w] += 1.3 * env * np.sin(chirp_phase)

    # 4) RFI urbano: portadoras estrechas intermitentes
    if include_rfi:
        rfi_freqs = [880.0, 1520.0, 2450.0, 3300.0]
        for fr in rfi_freqs:
            on_mask = rng.random(n) < 0.12  # intermitente
            amp = rng.uniform(0.2, 0.6)
            signal += amp * on_mask * np.sin(2 * np.pi * fr * t + rng.uniform(0, 2 * np.pi))

    # Normalizar a rango ~[-1, 1]
    signal = signal / (np.max(np.abs(signal)) + 1e-9)

    meta = {
        "source": "simulated",
        "duration_s": duration,
        "fs": fs,
        "components": ["cosmic_noise", "HI_21cm_line", "dispersed_pulsar", "RFI_urban"],
        "seed": seed,
    }
    return signal.astype(np.float32), float(fs), meta


def load_wav(path: str) -> tuple[np.ndarray, float, dict]:
    """Carga un WAV mono (o promedia canales). Requiere scipy."""
    from scipy.io import wavfile

    fs, data = wavfile.read(path)
    if data.ndim > 1:
        data = data.mean(axis=1)
    data = data.astype(np.float32)
    if np.issubdtype(data.dtype, np.integer):
        data = data / np.iinfo(data.dtype).max
    meta = {"source": f"wav:{path}", "duration_s": len(data) / fs, "fs": fs}
    return data, float(fs), meta


def load_sdr_iq(path: str, fs: float = 2.4e6, dtype: str = "int8") -> tuple[np.ndarray, float, dict]:
    """Stub para archivos IQ de SDR (RTL-SDR: int8 interleaved I/Q).

    Convierte IQ compleja a magnitud de banda base y la downsamplea a audio.
    Implementacion minima: para uso real se recomienda GNU Radio / pyrtlsdr.
    """
    raw = np.fromfile(path, dtype=np.int8)
    i = raw[0::2].astype(np.float32)
    q = raw[1::2].astype(np.float32)
    iq = i + 1j * q
    magnitude = np.abs(iq)
    # Diezmado brutal a ~22kHz para el pipeline
    factor = max(1, int(fs / 22050))
    audio_rate = fs / factor
    down = magnitude[: len(magnitude) // factor * factor].reshape(-1, factor).mean(axis=1)
    down = (down - down.mean()) / (down.std() + 1e-9)
    meta = {"source": f"sdr_iq:{path}", "fs_iq": fs, "fs_audio": audio_rate}
    return down.astype(np.float32), float(audio_rate), meta
