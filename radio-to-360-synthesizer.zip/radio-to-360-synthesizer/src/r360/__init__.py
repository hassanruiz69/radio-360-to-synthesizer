"""Radio-to-360 Spatial Synthesizer (r360).

Traduce senales de radio / audio / espectros electromagneticos a imagenes
equirectangulares 360 grados (aspect ratio 2:1) aptas para visualizacion
inmersiva (WebXR / planetarios / worldbuilding).

Este es un proyecto de DATA ART y DIVULGACION. El mapeo senal->geometria es
expresivo, no cientificamente invertible. Ver README para la evaluacion de
viabilidad en astronomia real.
"""

__version__ = "0.1.0"
